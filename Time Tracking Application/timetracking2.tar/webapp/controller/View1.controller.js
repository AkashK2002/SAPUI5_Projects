sap.ui.define([
  "sap/ui/core/mvc/Controller",
  "timetracking2/model/formatter",
  "sap/ui/export/Spreadsheet"
], function (Controller, formatter, Spreadsheet) {
  "use strict";

  return Controller.extend("timetracking2.controller.View1", {
      formatter: formatter,

      onInit: function () {
        
              },

              onGoPress: function () {
                console.log("working")
                const oView = this.getView();
                const oTable = oView.byId("idProductsTable");
                const oBinding = oTable.getBinding("items");
                var oModel = this.getOwnerComponent().getModel("MainModel");
                // Get the data from the model
                var oData = oModel.getData();
                // Log the data to the console
                console.log("ODATA: ",oData);                
             
            //     // Gather filter values
                const activityType = oView.byId("activityTypeSelect").getSelectedKey();
                const orderNo = oView.byId("orderInput").getValue();
                const users = oView.byId("userSelect").getSelectedKeys();
                const workCenter = oView.byId("workCenterSelect").getSelectedKey();
                const statuses = oView.byId("statusSelect").getSelectedKeys();
                const dateFrom = oView.byId("timeRangePicker").getDateValue();
                const dateTo = oView.byId("timeRangePicker").getSecondDateValue();
             
                // Build Filters array
                const aFilters = [];
                if (activityType) {
                    aFilters.push(new sap.ui.model.Filter("ActivityType", sap.ui.model.FilterOperator.EQ, activityType));
                }
                if (orderNo) {
                    aFilters.push(new sap.ui.model.Filter("OrderNo", sap.ui.model.FilterOperator.Contains, orderNo));
                }
                if (users && users.length > 0) {
                    const userFilters = users.map(user => new sap.ui.model.Filter("UserTt", sap.ui.model.FilterOperator.EQ, user));
                    aFilters.push(new sap.ui.model.Filter({ filters: userFilters, and: false }));
                }
                if (workCenter) {
                    aFilters.push(new sap.ui.model.Filter("WorkCenter", sap.ui.model.FilterOperator.EQ, workCenter));
                }
                if (statuses && statuses.length > 0) {
                    const statusFilters = statuses.map(status => new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, status));
                    aFilters.push(new sap.ui.model.Filter({ filters: statusFilters, and: false }));
                }
                if (dateFrom && dateTo) {
                    const oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({ pattern: "yyyyMMdd" });
                    const sDateFrom = oDateFormat.format(dateFrom);
                    const sDateTo = oDateFormat.format(dateTo);
                    aFilters.push(new sap.ui.model.Filter("StartTime", sap.ui.model.FilterOperator.BT, sDateFrom, sDateTo));
                }
             
                oBinding.filter(aFilters);
             
                // --------- User Utilization Calculation ---------
                let filteredData = [], totalSeconds = 0, utilization = 0;
             
                if (dateFrom && dateTo && users && users.length === 1) {
                    const selectedUser = users[0];
                    const aData = oModel.getProperty("/ztimetrackSet");
                    console.log("Data in ztimetrackSet",aData)
             
                    if (!Array.isArray(aData)) {
                        console.error("ztimetrackSet is not an array or is null:", aData);
                        oModel.setProperty("/userUtilization", 0);
                        sap.m.MessageToast.show("No data available for utilization calculation.");
                        return;
                    }
             
                    const selectedDates = [];
                    let currentDate = new Date(dateFrom);
                    let lastDate = new Date(dateTo);
             
                    currentDate.setHours(0, 0, 0, 0);
                    lastDate.setHours(0, 0, 0, 0);
             
                    while (currentDate <= lastDate) {
                        selectedDates.push(currentDate.toISOString().split("T")[0]);
                        currentDate.setDate(currentDate.getDate() + 1);
                    }
             
                    // Filter relevant records
                    filteredData = aData.filter(item => {
                        if (!item.StartTime) return false;
                        const itemDate = item.StartTime.split("T")[0];
                        return item.UserTt === selectedUser && selectedDates.includes(itemDate);
                    });
             
                    // Sum durations (in seconds)
                    totalSeconds = 0;
                    filteredData.forEach(item => {
                        if (item.Duration) {
                            if (typeof item.Duration === "string" && item.Duration.startsWith("PT")) {
                                const match = item.Duration.match(/PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?/);
                                if (match) {
                                    const hours = parseInt(match[1] || "0", 10);
                                    const minutes = parseInt(match[2] || "0", 10);
                                    const seconds = parseInt(match[3] || "0", 10);
                                    totalSeconds += (hours * 3600) + (minutes * 60) + seconds;
                                }
                            } else if (!isNaN(item.Duration)) {
                                totalSeconds += parseInt(item.Duration, 10) * 60;
                            }
                        }
                    });
             
                    const totalHours = totalSeconds / 3600;
             
                    // --- Modified Section: Only Count Working Days (Mon–Sat, exclude Sunday) ---
                    let workingDays = 0;
                    selectedDates.forEach(dateStr => {
                        const day = new Date(dateStr).getDay();
                        if (day !== 0) { // 0 = Sunday
                            workingDays++;
                        }
                        console.log(workingDays)
                    });
                   
             
                    const availableHours = workingDays * 8;
                    utilization = availableHours > 0 ? (totalHours / availableHours) * 100 : 0;
                    oModel.setProperty("/userUtilization", utilization);
             
                } else {
                   // oModel.setProperty("/userUtilization", 0);
                   this.getView().setModel(new sap.ui.model.json.JSONModel({
                    userUtilization: 0
                }), "MainModel");
                }
             
                // ---------- End Utilization Calculation ----------
                this.calculateWorkCenterUtilization && this.calculateWorkCenterUtilization();
                sap.m.MessageToast.show("Filters applied");
             
                // Logs
                console.log("Filtered Records:", filteredData);
                console.log("Total Seconds:", totalSeconds);
                console.log("Utilization:", utilization);
            },
             
            gobutton: function(oEvent) {
                console.log("working")
            },
      
      onSendReportPress: function() {
        var oView = this.getView();
        var oModel = oView.getModel("MainModel");
        
        // Get selected values
        var aSelectedUsers = oView.byId("userSelect").getSelectedKeys();
        var sSelectedWorkCenter = oView.byId("workCenterSelect").getSelectedKey();
        var oDateRangeSelection = oView.byId("timeRangePicker");
        console.log("date range:", oDateRangeSelection)
        
        // Get start and end dates
        var oStartDate = oDateRangeSelection.getDateValue();
        var oEndDate = oDateRangeSelection.getSecondDateValue();
        
        // Check if dates are valid
        if (!oStartDate || !oEndDate) {
            sap.m.MessageToast.show("Please select a valid time range");
            return;
        }
    
        // Format dates to ISO string if needed
        var sStartDate = oStartDate ? oStartDate.toISOString() : null;
        var sEndDate = oEndDate ? oEndDate.toISOString() : null;
    
        var nUserUtilization = 20;
        var nWorkCenterUtilization = 70; // Default value or get from model if available
    
        if (!aSelectedUsers.length) {
            sap.m.MessageToast.show("Please select at least one user");
            return;
        }
    
        if (!sSelectedWorkCenter) {
            sap.m.MessageToast.show("Please select a work center");
            return;
        }
    
        var formatDate = function(date) {
          var day = String(date.getDate()).padStart(2, '0');
          var month = String(date.getMonth() + 1).padStart(2, '0'); // Months are zero-based
          var year = date.getFullYear();
          return `${day}${month}${year}`; // Format as DDMMYYYY
      };
      var sStartDate = formatDate(oStartDate);
      var sEndDate = formatDate(oEndDate);

        var dateRangeString = `${sStartDate}`;

        // Prepare payload
        var oPayload = {
            "User3": "P123",
            "WorkCenter": sSelectedWorkCenter,
            "TimeRange": dateRangeString,
            "UserUtilization": "100",
            "WorkcenterUtilization": "70"
        };
    
        // Create OData request
        oModel.create("/TimeTrackutilizationSet", oPayload, {
            success: function() {
                sap.m.MessageToast.show("Report successfully sent to backend");
                // Optional: refresh the table or clear selections
            },
            error: function(oError) {
                sap.m.MessageToast.show("Error sending report: " + oError.message);
            },
            async: true
        });
    },
       
      

    
      
    onDownloadPress: function () {
        const oTable = this.byId("idProductsTable");
        const oBinding = oTable.getBinding("items");
        const aContexts = oBinding.getContexts();
        const aData = aContexts.map(context => context.getObject());
    
        if (aData.length === 0) {
            sap.m.MessageToast.show("No data available for download.");
            return;
        }
    
        const aCols = [
            { label: 'User', property: 'UserTt' },
            { label: 'Activity Type', property: 'ActivityType' },
            { label: 'Start Time', property: 'StartTime' },
            { label: 'Duration', property: 'Duration' },
            { label: 'Order No', property: 'OrderNo' },
            { label: 'SFC', property: 'Sfc' },
            { label: 'Work Center', property: 'WorkCenter' },
            { label: 'Status', property: 'Status' }
        ];
    
        const oSettings = {
            workbook: { columns: aCols },
            dataSource: aData,
            fileName: 'TimeTrackingReport.xlsx'
        };
    
        const oSheet = new sap.ui.export.Spreadsheet(oSettings);
        oSheet.build().finally(function () {
            oSheet.destroy();
        });
    },    

      onClearPress: function () {
        console.log("working")
          const oView = this.getView();

          oView.byId("activityTypeSelect").setSelectedKey("");
          oView.byId("orderInput").setValue("");
          oView.byId("userSelect").setSelectedKeys([]);
          oView.byId("workCenterSelect").setSelectedKey("");
          oView.byId("statusSelect").setSelectedKeys([]);
          oView.byId("timeRangePicker").setDateValue(null);
          oView.byId("timeRangePicker").setSecondDateValue(null);

          const oModel = oView.getModel("MainModel");
          oModel.setProperty("/selectedActivityType", null);
          oModel.setProperty("/selectedUserTt", []);
          oModel.setProperty("/selectedWorkCenter", null);
          oModel.setProperty("/selectedStatus", []);
          oModel.setProperty("/workCenterUtilization", 0);
          oModel.setProperty("/workCenterUtilizationDisplay", "0%");
      },

      

      
  });
});
