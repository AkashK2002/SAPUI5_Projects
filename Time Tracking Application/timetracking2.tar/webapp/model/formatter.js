sap.ui.define([], function () {
    "use strict";
  
    return {
      formatVerboseDate: function (timestamp) {
        // Validate input
        if (!timestamp || timestamp.length < 14) {
          return "Invalid timestamp";
        }
      
        // Extract date and time components
        const year = timestamp.substring(0, 4);
        const month = timestamp.substring(4, 6);
        const day = timestamp.substring(6, 8);
        const hour = timestamp.substring(8, 10);
        const minute = timestamp.substring(10, 12);
        const second = timestamp.substring(12, 14);
      
        // Construct ISO date string
        const isoString = `${year}-${month}-${day}T${hour}:${minute}:${second}`;
      
        // Create Date object
        const date = new Date(isoString);
      
        // Format options
        const options = {
          weekday: 'long',
          year: 'numeric',
          month: 'long',
          day: 'numeric',
          hour: 'numeric',
          minute: 'numeric',
          second: 'numeric',
          hour12: true
        };
      
        // Return formatted string
        return date.toLocaleString('en-US', options);
      },      
  
      convertCustomDuration: function (isoDuration) {
        const regex = /PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?/;
        const match = isoDuration.match(regex);
      
        if (!match) return "Invalid format";
      
        const hours = parseInt(match[1] || "0", 10);
        const minutes = parseInt(match[2] || "0", 10);
        const seconds = parseInt(match[3] || "0", 10);
      
        const totalSeconds = (hours * 3600) + (minutes * 60) + seconds;
      
        const totalMinutes = Math.floor(totalSeconds / 60);
        const days = Math.floor(totalMinutes / 480); // Assuming 1 workday = 480 minutes
        const remainingMinutes = totalMinutes % 480;
        const finalHours = Math.floor(remainingMinutes / 60);
        const finalMinutes = remainingMinutes % 60;
        const finalSeconds = totalSeconds % 60;
      
        const parts = [];
        if (days) parts.push(`${days} days`);
        if (finalHours) parts.push(`${finalHours} hours`);
        if (finalMinutes) parts.push(`${finalMinutes} minutes`);
        if (finalSeconds) parts.push(`${finalSeconds} seconds`);
      
        return parts.length > 0 ? parts.join(" ") : "0 seconds";
      },
            
  
      formatStatus: function (sStatus) {
        switch (sStatus?.toLowerCase()) {
          case "new":
          case "approved":
            return "Success";
          case "changed":
            return "Warning";
          case "deleted":
          case "approval failed":
          case "canceled":
          case "cancelation failed":
            return "Error";
          default:
            return "None";
        }
      }
    };
  });
  